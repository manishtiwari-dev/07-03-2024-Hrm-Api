<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\HRM\Http\Controllers\DepartmentController;
use Modules\HRM\Http\Controllers\DesignationController; 
use Modules\HRM\Http\Controllers\EducationController; 
use Modules\HRM\Http\Controllers\DocumentTypeController;
use Modules\HRM\Http\Controllers\LeaveController;
use Modules\HRM\Http\Controllers\LeaveTypeController;
use Modules\HRM\Http\Controllers\SettingsController;
use Modules\HRM\Http\Controllers\AttendanceController;
use Modules\HRM\Http\Controllers\StaffController;
use Modules\HRM\Http\Controllers\HolidayController;
use Modules\HRM\Http\Controllers\SalaryController; 
use Modules\HRM\Http\Controllers\HRMReportsController;



/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => ['ApiTokenCheck'], 'prefix' => "api/"], function () {

    //Department API
    Route::group(['prefix' => 'department'], function () {
        Route::post('/all', [DepartmentController::class, 'index_all']);
        Route::post('/', [DepartmentController::class, 'index']);
        Route::post('/store', [DepartmentController::class, 'store']);
        Route::post('/edit', [DepartmentController::class, 'edit']);
        Route::post('/update', [DepartmentController::class, 'update']);
        Route::post('/delete', [DepartmentController::class, 'destroy']);
        Route::post('/changeStatus', [DepartmentController::class, 'changeStatus']);
    });
    //end Department API

    //Designation API
    Route::group(['prefix' => 'designation'], function () {
        Route::post('/all', [DesignationController::class, 'index_all']);
        Route::post('/', [DesignationController::class, 'index']);
        Route::post('/store', [DesignationController::class, 'store']);
        Route::post('/edit', [DesignationController::class, 'edit']);
        Route::post('/update', [DesignationController::class, 'update']);
        Route::post('/delete', [DesignationController::class, 'destroy']);
        Route::post('/changeStatus', [DesignationController::class, 'changeStatus']);
    });


     //Designation API
    Route::group(['prefix' => 'education'], function () {
        Route::post('/all', [EducationController::class, 'index_all']);
        Route::post('/', [EducationController::class, 'index']);
        Route::post('/store', [EducationController::class, 'store']);
        Route::post('/edit', [EducationController::class, 'edit']);
        Route::post('/update', [EducationController::class, 'update']);
        Route::post('/delete', [EducationController::class, 'destroy']);
        Route::post('/changeStatus', [EducationController::class, 'changeStatus']);
    });

     //document type API
    Route::group(['prefix' => 'doc-type'], function () {
        Route::post('/all', [DocumentTypeController::class, 'index_all']);
        Route::post('/', [DocumentTypeController::class, 'index']);
        Route::post('/store', [DocumentTypeController::class, 'store']);
        Route::post('/edit', [DocumentTypeController::class, 'edit']);
        Route::post('/update', [DocumentTypeController::class, 'update']);
        Route::post('/delete', [DocumentTypeController::class, 'destroy']);
        Route::post('/changeStatus', [DocumentTypeController::class, 'changeStatus']);
    });



    //end Designation API

    //LeaveType API
    Route::group(['prefix' => 'leaveType'], function () {
        Route::post('/', [LeaveTypeController::class, 'index']);
        Route::post('/store', [LeaveTypeController::class, 'store']);
        Route::post('/edit', [LeaveTypeController::class, 'edit']);
        Route::post('/update', [LeaveTypeController::class, 'update']);
        Route::post('/delete', [LeaveTypeController::class, 'destroy']);
    });
    //end LeaveType API

     //settings API
    Route::group(['prefix' => 'hrm-settings'], function () {
        Route::post('/', [SettingsController::class, 'index']);
        Route::post('/store', [SettingsController::class, 'store']);
        Route::post('/edit', [SettingsController::class, 'edit']);
        Route::post('/update', [SettingsController::class, 'update']);
        Route::post('/delete', [SettingsController::class, 'destroy']);
    });
    //end settings API

    

    //Leave API
    Route::group(['prefix' => 'leave'], function () {
        Route::post('/', [LeaveController::class, 'index']);
        Route::post('/store', [LeaveController::class, 'store']);
        Route::post('/create', [LeaveController::class, 'create']);
        Route::post('/edit', [LeaveController::class, 'edit']);
        Route::post('/update', [LeaveController::class, 'update']);
        Route::post('/status', [LeaveController::class, 'statusChange']);
        Route::post('/leavePaystatus', [LeaveController::class, 'leavePaystatus']);
    });
    //end Leave API

    //Staff API
    Route::group(['prefix' => 'staff'], function () {
        Route::post('/', [StaffController::class, 'index']);
        Route::post('/create', [StaffController::class, 'create']);
        Route::post('/store', [StaffController::class, 'store']);
        Route::post('/edit', [StaffController::class, 'edit']);
        Route::post('/update', [StaffController::class, 'update']);
        Route::post('/changeStatus', [StaffController::class, 'changeStatus']);
        Route::post('/verify', [StaffController::class, 'verification']);
        Route::post('/terminate', [StaffController::class, 'terminate']);
        Route::post('/performance', [StaffController::class, 'performance']);
        Route::post('/perfor-edit', [StaffController::class, 'performEdit']);
        Route::post('/performance-update', [StaffController::class, 'performanceUpdate']);
        Route::post('/remuneration', [StaffController::class, 'remunerationAdd']);
        Route::post('/remuneration-edit', [StaffController::class, 'remunerationEdit']);
        Route::post('/remuneration-update', [StaffController::class, 'remunerationUpdate']);
        Route::post('/bank-details', [StaffController::class, 'bankDetails']);
        Route::post('/bank-details-update', [StaffController::class, 'bankDetailsUpdate']);
        Route::post('/bank-details-edit', [StaffController::class, 'bankDetailsEdit']);
        Route::post('/import-store', [StaffController::class, 'impotStore']);


       


    });
    //end Staff API

    //Attendence API
    Route::group(['prefix' => 'attendance'], function () {
        Route::post('/', [AttendanceController::class, 'index']);
        Route::post('/create', [AttendanceController::class, 'create']);
        Route::post('/check-in', [AttendanceController::class, 'checkIn']);
        Route::post('/check-out', [AttendanceController::class, 'checkOut']);
        Route::post('/select_dept', [AttendanceController::class, 'select_dept']);
        Route::post('/attend-data', [AttendanceController::class, 'attendData']);
        Route::post('/storeClockIn', [AttendanceController::class, 'storeClockIn']);
        Route::post('/updateClockIn', [AttendanceController::class, 'updateClockIn']);
        Route::post('/export-attendance', [AttendanceController::class, 'exportAttendance']);
        Route::post('/details-attendance', [AttendanceController::class, 'attendDetails']);

        Route::post('/attendance-updates', [AttendanceController::class, 'attendUpdate']);

        



    });

    //end Attendence API


    //start holyday 
    Route::group(['prefix' => 'holyday'], function () {
        Route::post('/', [HolidayController::class, 'index']);
        Route::post('/store', [HolidayController::class, 'store']);
        Route::post('/create', [HolidayController::class, 'create']);
        Route::post('/edit', [HolidayController::class, 'edit']);
        Route::post('/update', [HolidayController::class, 'update']);
        Route::post('/delete', [HolidayController::class, 'destroy']);
        Route::post('/markDayHoliday', [HolidayController::class, 'markDayHoliday']);
    });
    //end holyday


    //employee salary
    Route::group(['prefix' => 'salary'], function () {
        Route::post('/', [SalaryController::class, 'index']);
        Route::post('/store', [SalaryController::class, 'store']);
        Route::post('/create', [SalaryController::class, 'create']);
        Route::post('/edit', [SalaryController::class, 'edit']);
        Route::post('/update', [SalaryController::class, 'update']);
        Route::post('/delete', [SalaryController::class, 'destroy']); 
        Route::post('/generate-salary', [SalaryController::class, 'generateSalary']); 
        Route::post('/salary-generate-section', [SalaryController::class, 'generateSalarySection']); 
        Route::post('/status', [SalaryController::class, 'changeStatus']); 
        Route::post('/export-salary', [SalaryController::class, 'exportSalary']); 
    });
    //end employee salary

    //hrm reports route start
    
    Route::group(['prefix' => 'hrm-reports'], function () {
        Route::post('/', [HRMReportsController::class, 'index']); 
        Route::post('/export', [HRMReportsController::class, 'reportExport']);  
    });

    //hrm reprts route end

});
