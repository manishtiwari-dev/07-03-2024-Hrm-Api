<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use Modules\HRM\Models\Staff;
use DB;

class AttendenceReport extends Model
{
    use HasFactory;

    // protected $fillable = [
    //     'user_id',
    //     'check_in',
    //     'check_out',
    //     'day',
    //     'month',
    //     'year',
    //     'attendance_date',
    // ];


    protected $primaryKey = 'id';


    protected $guarded = [
        'id'
    ];

    public function getTable()
    {
        return config('dbtable.common_hrm_attendances');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function user_list()
    {
        return $this->belongsTo(Staff::class, 'user_id', 'staff_id');
    }


    // Get User Clock-ins by date
    public static function getTotalUserClockIn($date, $userId)
    {
        return AttendenceReport::where(DB::raw('DATE(hrm_attendances.clock_in_time)'), $date)
            ->where('staff_id', $userId)
            ->count();
    }
}
