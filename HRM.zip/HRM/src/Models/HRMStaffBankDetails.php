<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HRMStaffBankDetails extends Model
{
    use HasFactory;
    protected $primaryKey = "id";
    protected $fillable = [
        'staff_id',
        'account_name',
        'account_number',  
        'bank_name',  
        'bank_indetifier_coder',  
        'bank_branch',  
    ];
    
    public $timestamps = false;

    public function getTable(){
        return config('dbtable.hrm_staff_bank_details');
    }


}
