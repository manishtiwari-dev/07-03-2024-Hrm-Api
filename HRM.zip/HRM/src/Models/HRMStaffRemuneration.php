<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HRMStaffRemuneration extends Model
{
    use HasFactory;
    protected $primaryKey = "remuneration_id";
    protected $fillable = [
        'staff_id',
        'remuneration_type',
        'remuneration_date',
        'remuneration_value',  
    ];
    
    public $timestamps = false;

    public function getTable(){
        return config('dbtable.hrm_staff_remuneration');
    }


}
