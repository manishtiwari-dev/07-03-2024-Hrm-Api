<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffRemark extends Model
{
    use HasFactory;
    protected $primaryKey = "remark_id";
    protected $fillable = [
        'staff_id',
        'remark_type',
        'remark_grade',
        'remark_details',
        'updated_at',
    ];
    public $timestamps = false;

    public function getTable(){
        return config('dbtable.hrm_staff_remark');
    }


}
