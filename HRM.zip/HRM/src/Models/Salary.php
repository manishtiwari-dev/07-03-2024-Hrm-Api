<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Country;

class Salary extends Model
{
    use HasFactory;

    protected $primaryKey = "id";

    protected $fillable = [
        'staff_id',
        'total_days',
        'total_leave',
        'paid_leave',
        'paid_days',
        'salary_month',
        'salary_year',
        'salary_amount',
        'payment_date',
        'payment_status', 
    ];

    public function getTable(){
        return config('dbtable.hrm_salary');
    }     

    public function staff(){
        return $this->belongsTo(Staff::class,'staff_id','staff_id');
    }

    public function remuneration(){
        return $this->belongsTo(HRMStaffRemuneration::class,'staff_id','staff_id');
    }

    

}
