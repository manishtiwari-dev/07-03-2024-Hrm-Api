<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffDocument extends Model
{
    use HasFactory;
    protected $primaryKey = "staff_doc_id";
    protected $fillable = [
        'staff_id',
        'document_id',
        'document_file',
        'status',
    ];
    public $timestamps = false;

    public function getTable(){
        return config('dbtable.hrm_staff_document');
    }
    public function doc_info(){
        return $this->belongsTo(Document::class,'document_id','document_id');
    }

}
