<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use Modules\HRM\Models\Staff;
use Modules\HRM\Models\LeaveType;

class Leave extends Model
{
    use HasFactory;

    protected $primaryKey = "id";

    protected $guarded=[
     
        'id',
   
   
       ];

    public function getTable(){
        return config('dbtable.common_leave');
    }

    public function user(){
        return $this->belongsTo(User::class,'user_id','id');
    }

    public function leave_type(){
        return $this->belongsTo(LeaveType::class,'leave_type_id','leave_type_id');
    }


    public function staff(){
        return $this->belongsTo(Staff::class,'staff_id','staff_id');
    }




}
