<?php

namespace Modules\HRM\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize; 
use Carbon\Carbon;  
use Maatwebsite\Excel\Concerns\WithHeadings;
use Modules\HRM\Models\Salary; 
use Modules\HRM\Models\Staff; 
use Modules\HRM\Models\AttendenceReport; 
use Maatwebsite\Excel\Sheet;


class ReportsExport implements FromCollection, ShouldAutoSize, WithHeadings
{
    use Exportable;

     public function collection()
    { 
        $month =  !empty($request->month) ? $request->month : now()->month;
        $year = !empty($request->year) ? $request->year : now()->year; 

        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);

        

        $result = collect([]);
        $staff = Staff::with('salaryAmt');

        $user_id = "all";

        if ($user_id != 'all') {
            $staff = $staff->where('staff_id', $user_id);
        }
 

        $stafflist = $staff->get();

        $monthWiseData = []; 
            foreach($stafflist as $staff){ 
               $dataVal = []; 
               $dataVal[] = $staff->staff_name; 
               $data = [];
               $TP = $TL = $TPL = $TS = 0;
                for ($month = 1; $month <= 12; $month++) { 
                    $present = AttendenceReport::where('staff_id' , $staff->staff_id)->whereMonth('clock_in_time' , $month)->whereYear('clock_in_time' , $year)->where('status' , 'present')->count();
                    $absent = AttendenceReport::where('staff_id' , $staff->staff_id)->whereMonth('clock_in_time' , $month)->whereYear('clock_in_time' , $year)->where('status' , 'absent')->count();
                    $staff_salary = Salary::where('salary_month' , $month)->where('salary_year' , $year)->where('staff_id' , $staff->staff_id)->first();

 
                    $date = Carbon::createFromDate($year, $month, 1);
                    $totalDays = $date->daysInMonth;
 
                    $TP += $present; 
                    $TL += $staff_salary->total_leave ?? 0;
                    $TPL += $staff_salary->paid_leave ?? 0;
                    $TS += $staff_salary->salary_amount ?? 0;

                    
                   $value = [
                                "attend"      => "P: " . $present . " ",
                                "leave"       => "L: " . ($staff_salary->total_leave ?? 0). " ",
                                "paid_leave"  => "PL: " . ($staff_salary->paid_leave ?? 0). " ",
                                "salaryAmt"   => "S: " . ($staff_salary->salary_amount ?? 0). " ",
                            ];

                   

                    
                    $dataVal[] = $value["attend"].$value["leave"].$value["paid_leave"].$value["salaryAmt"];
                    
  
                }
                $Total = [
                        "attend"      => "P: " . $TP . " ",
                        "leave"       => "L: " . $TL. " ",
                        "paid_leave"  => "PL: " . $TPL. " ",
                        "salaryAmt"   => "S: " . $TS. " ",
                    ];
                $dataVal[] = $Total["attend"].$Total["leave"].$Total["paid_leave"].$Total["salaryAmt"];

                 $result->add([
                    $dataVal,   
                 ]);
                
                
            }

            return $result;
    }

    public function headings(): array
    {
        return ['Employee','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Total'];
    }
 
}
