<?php

namespace Modules\HRM\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize; 
use Carbon\Carbon;  
use Maatwebsite\Excel\Concerns\WithHeadings;
use Modules\HRM\Models\AttendenceReport; 
use Maatwebsite\Excel\Sheet;
use Modules\HRM\Models\Holiday;
use Modules\HRM\Models\LeaveType;
use Modules\HRM\Models\Leave;
use Modules\HRM\Models\Staff;


class ExportAttendance implements FromCollection, ShouldAutoSize, WithHeadings
{
    use Exportable;

    protected $filters;

    public function __construct(array $filters)
    {
        $this->filters = $filters; 
    }

    

    

    public function collection()
    {
        $data = "";
        $result = collect([]);
        $employees = Staff::with(
            [
                'attend' => function ($query) use ($data) {
                    $query->whereRaw('MONTH(hrm_attendances.clock_in_time) = ?', [$this->filters['month']])
                        ->whereRaw('YEAR(hrm_attendances.clock_in_time) = ?', [$this->filters['year']])
                        ->whereRaw('status=?', 'present');
                },

                'leaves' => function ($query) use ($data) {
                    $query->whereRaw('MONTH(hrm_leaves.leave_date) = ?', [$this->filters['month']])
                        ->whereRaw('YEAR(hrm_leaves.leave_date) = ?', [$this->filters['year']])
                        ->where('status', 'approved');
                }
            ]

        );

        if ($this->filters['staff'] != 'all') {
            $employees = $employees->where('staff_id', $this->filters['staff']);
        }



        $employees = $employees->get();


        $holidays = Holiday::whereRaw('MONTH(hrm_holidays.date) = ?', [$this->filters['month']])->whereRaw('YEAR(hrm_holidays.date) = ?', [$this->filters['year']])->get();


        $final = [];
        $holidayOccasions = [];

        $daysInMonth = Carbon::parse('01-' . $this->filters['month'] . '-' . $this->filters['year'])->daysInMonth;
        $now = Carbon::now();
        $requestedDate = Carbon::parse(Carbon::parse('01-' . $this->filters['month'] . '-' . $this->filters['year']))->endOfMonth();


        foreach ($employees as $employee) {
            $employees_name = $employee->staff_name;

            $dataBeforeJoin = null;

            $dataTillToday = array_fill(1, $now->copy()->format('d'), 'A');

            if (($now->copy()->format('d') != $daysInMonth) && !$requestedDate->isPast()) {
                $dataFromTomorrow = array_fill($now->copy()->addDay()->format('d'), ((int)$daysInMonth - (int)$now->copy()->format('d')), '-');
            } else {
                $dataFromTomorrow = array_fill($now->copy()->addDay()->format('d'), ((int)$daysInMonth - (int)$now->copy()->format('d')), 'A');
            }


            $final[$employee->staff_id . '#' . $employee->staff_name] = array_replace($dataTillToday, $dataFromTomorrow);
 
 
            if (!empty($employee->attend)) {
                foreach ($employee->attend as $attendance) {  
                    $final[$employee->staff_id . '#' . $employee->staff_name][Carbon::parse($attendance->clock_in_time)->day] = 'P';
                }
            }

            if (Carbon::parse('01-' . $this->filters['month'] . '-' . $this->filters['year'])->isFuture()) {
                $dataBeforeJoin = array_fill(1, $daysInMonth, '-');
            }

            if (!is_null($dataBeforeJoin)) {
                $final[$employee->staff_id . '#' . $employee->staff_name] = array_replace($final[$employee->staff_id . '#' . $employee->staff_name], $dataBeforeJoin);
            }

            foreach ($employee->leaves as $leave) {

                $final[$employee->staff_id . '#' . $employee->staff_name][Carbon::parse($leave->leave_date)->day] = 'L';
            }



            foreach ($holidays as $holiday) {

                if ($final[$employee->staff_id . '#' . $employee->staff_name][Carbon::parse($holiday->date)->day] == 'A' || $final[$employee->staff_id . '#' . $employee->staff_name][Carbon::parse($holiday->date)->day] == '-') {
                    $final[$employee->staff_id . '#' . $employee->staff_name][Carbon::parse($holiday->date)->day] = 'H';
                    $holidayOccasions[Carbon::parse($holiday->date)->day] = $holiday->occassion;

                }
            }
        }

         
         foreach ($final as $key => $values){
            $dataVal = [];  
            $p = $a = $h = $l= 0; 

            $input = explode('#', $key);  

                $dataVal[] = $input[1];

            foreach ($values as $date => $status){

                $dataVal[] = $status;
                if($status=='P'){
                    $p+=1;
                }else if($status=='A'){
                    $a+=1;
                }else if($status=='H'){
                    $h+=1;
                }else if($status=='L'){
                    $l+=1;
                }
            } 
            $dataVal[] = $p;
            $dataVal[] = $a;
            $dataVal[] = $h;
            $dataVal[] = $l;
            
            $result->add([
                    $dataVal,  
                 ]);
        }

        

        return $result;

    }
    


    public function headings(): array
    {
        $days = Carbon::now()->month($this->filters['month'])->daysInMonth;
        $daysNumber = [];
        $daysNumber = ['Staff Name'];
        for ($date = 1; $date <= $days; $date++){ 
             $daysNumber[] =   $date;
        } 

        $daysNumber[] = 'Total Prasent';
        $daysNumber[] = 'Total Absent';
        $daysNumber[] = 'Total Holiday';
        $daysNumber[] = 'Total Leave';

        return $daysNumber;

         
    }
 
}
