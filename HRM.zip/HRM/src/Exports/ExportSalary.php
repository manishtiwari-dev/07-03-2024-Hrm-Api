<?php

namespace Modules\HRM\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize; 
use Carbon\Carbon;  
use Maatwebsite\Excel\Concerns\WithHeadings;
use Modules\HRM\Models\Salary; 
use Maatwebsite\Excel\Sheet;


class ExportSalary implements FromCollection, ShouldAutoSize, WithHeadings
{
    use Exportable;

    protected $filters;

    public function __construct(array $filters)
    {
        $this->filters = $filters; 
    }

    

    public function headings(): array
    {
        return ['Staff Name', 'Total Days', 'Total Leave','Paid Leave' ,'Paid Days', 'Salary Month', 'Salary Year', 'Salary Amount', 'Payment Date', 'Payment Status'];
    }

     public function collection()
    { 
        $salary = Salary::with('staff');

        // Filter  By user_id
        if ($this->filters['user_id'] != 'all' && $this->filters['user_id'] != '') {
            $salary = $salary->where('staff_id' , $this->filters['user_id']);
        }

        // Filter  By month
        if ($this->filters['month'] != 'all' && $this->filters['month'] != '') {
            $salary = $salary->where('salary_month' , $this->filters['month']);
        }


        // Filter  By year
        if ($this->filters['user_id'] != 'all' && $this->filters['user_id'] != '') {
            $salary = $salary->where('salary_year' , $this->filters['year']);
        }



        $salary = $salary->get();
 
        $transformedData = $salary->map(function ($user) {
            return [
                'staff_name' => $user->staff->staff_name ?? '',
                'total_days' => $user->total_days,
                'total_leave' => $user->total_leave,
                'paid_leave' => $user->paid_leave,
                'paid_days' => $user->paid_days,
                'salary_month' => $user->salary_month,
                'salary_year' => $user->salary_year,
                'salary_amount' => $user->salary_amount,
                'payment_date' => $user->payment_date,
                'payment_status' => ($user->payment_status == 1)?'Paid':'UnPaid',
            ];
        });

        return $transformedData;
    }
 
}
