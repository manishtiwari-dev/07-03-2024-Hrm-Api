<?php

namespace Modules\HRM\Http\Controllers;

use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\Http\Resources\UserResource;
use App\Models\Role;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\SuperUser;
use App\Models\Subscriber;
use App\Models\Subscription;
use App\Models\UserBusiness;
use App\Models\Module;
use App\Models\ModuleSection;
use App\Models\Industry;
use ApiHelper;
use App\Helper\Helper;
use Illuminate\Support\Facades\Storage;
use App\Mail\AutoGeneratePassword;
use Illuminate\Support\Facades\Mail;
use App\Jobs\SendAutoGeneratePasswordMail;
use Illuminate\Support\Facades\Config;
use App\Events\LoginEvent;
use Modules\HRM\Models\Staff;
use Modules\HRM\Models\Education;
use Modules\HRM\Models\Department;
use Modules\HRM\Models\Designation;
use Modules\HRM\Models\Document;
use Modules\HRM\Models\StaffDocument;
use Modules\HRM\Models\StaffWorkExp;
use Modules\HRM\Models\StaffQualification; 
use Modules\HRM\Models\Salary;
use Modules\HRM\Models\StaffAddress;
use Modules\HRM\Models\StaffRemark;
use Modules\HRM\Models\HRMStaffRemuneration;
use Modules\HRM\Models\HRMStaffBankDetails; 
use Modules\HRM\Models\AttendenceReport;
use Modules\HRM\Import\StaffImport;
use Maatwebsite\Excel\Facades\Excel;
use GuzzleHttp\Client;
use DB;

use App\Models\Country;


class StaffController extends Controller
{
    public $page = 'staff';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    /* get all userlist */
    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
 

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }
        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $user_query = Staff::where('created_by', ApiHelper::get_adminid_from_token($api_token));

        if (!empty($search))
            $user_query = $user_query
                ->where("staff_name", "LIKE", "%{$search}%")
                ->where("staff_email", "LIKE", "%{$search}%")
                ->orWhere("employee_id", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $user_query = $user_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $user_query = $user_query->orderBy('staff_id', 'DESC');
        }


        if ($request->department != 'all') {
            $user_query = $user_query->where('department_id', $request->department);
        }

        if($request->status != 'all'){
            $user_query = $user_query->where('status', $request->status);
        }

        // if($request->role != 'all'){
        //      $user_query = $user_query->where('leave_date', $request->role);
        // }



        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;

        $user_count = $user_query->count();

        $user_list = $user_query->skip($skip)->take($perPage)->get();

        $user_list = $user_list->map(function ($user) {


            $user->department_name = $user->department ? $user->department->dept_name : '';
            $user->designation_name = $user->designation ? $user->designation->designation_name : '';

            // $user->staff_photo = ApiHelper::getFullImageUrl($user->staff_photo);
             $user->staff_photo = Helper::FullImageUrl($user->staff_photo);

             $user->role_name = ApiHelper::staff_role($user->user_id);

            return $user;
        });



        $department_list = Department::where('status' , 1)->where('created_by', ApiHelper::get_adminid_from_token($api_token))
            ->get();
        $role_list = Role::all();


        $res = [
            'data' => $user_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage, 
            'department_list' => $department_list,
            'role_list' => $role_list
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create(Request $request)
    {
        $res = [];
        $api_token = $request->api_token;
        //   $res['user_list'] = User::where('created_by',ApiHelper::get_adminid_from_token($api_token))->get();
        $res['department_list'] = Department::where('status' , 1)->where('created_by', ApiHelper::get_adminid_from_token($api_token))
            ->get();
        $res['designation_list'] = Designation::where('status' , 1)->where('created_by', ApiHelper::get_adminid_from_token($api_token))
            ->get();
        $res['role_list'] = Role::all();
        $res['user_list'] = User::all();
        $res['country_list'] = Country::all();
        $res['education_list'] = Education::where('status', 1)->get();
        $res['document_list'] = Document::where('status', 1)->get();


        $res['qualification'] = Document::where('document_type' ,3)->where('status', 1)->get();
        $res['doc_types'] = Document::where('document_type' ,4)->where('status', 1)->get();
        $res['identity_doc'] = Document::where('document_type' ,1)->where('status', 1)->get();
        $res['address_doc'] = Document::where('document_type' ,2)->where('status', 1)->get();


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /* create user and assign role  */
    public function store(Request $request)
    {


        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        // validation check
        $rules = [
            'email' => 'required|string|email|max:255',
        ];
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email|max:255',
        ], [
            'email.required' => 'EMAIL_REQUIRED',
        ]);
        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }

        
            if ($request->user_type == 'new') {
                $user = User::where('email', $request->email)->first();
                if ($user === null) {

                    $user = User::create([
                        'first_name' => $request->name,
                        'last_name' => '',
                        'email' => $request->email,
                        'password' => Hash::make($request->password),
                        'created_by' => 1,
                        'api_token' => Hash::make($request->name),
                    ]);
 
                    $user->roles()->attach($request->role_name);
                }
            } else {
                $user = User::find($request->user_id);
            }

            $staffDetails = Staff::where('user_id', $user->id)->first();
            if ($staffDetails != null) {
                return ApiHelper::JSON_RESPONSE(false, [], 'ALREADY_STAFF_EXIST_FOR_THIS_USER');
            } else {

                $imageUrl = $request->fileInfo;
                if($imageUrl != ''){
                    $extension = pathinfo($imageUrl, PATHINFO_EXTENSION);

                    $file_name = 'profile' . uniqid() . '.' . $extension;
 
                    // Use Guzzle to fetch the image content
                    $client = new Client();
                    try {
                        $response = $client->get($imageUrl);
                        $imageData = $response->getBody()->getContents();

                        // Save the image to the storage folder
                        Storage::disk('public')->put($file_name, $imageData);
 

                        // Return the URL or use it as needed 
                    } catch (\Exception $e) {
                        // Handle the exception (e.g., log it or return an error response) 
                        return ApiHelper::JSON_RESPONSE(false, [], 'Failed to fetch image content');
                    }
 
                }else{
                    $file_name = '';
                }



                $staff = Staff::create([
                    'employee_id' => 'emp' . ApiHelper::generate_random_token('numeric', 6),
                    'user_id' => $user->id,
                    'department_id' => $request->department_id,
                    'designation_id' => $request->designation_id,
                    'gender' => $request->gender,
                    'staff_name' => $user->first_name, 
                    'staff_photo' => $file_name ?? '', 
                    'staff_email' => $user->email,
                    'staff_phone' => $request->phone_no,
                    'date_of_joining' => $request->date_of_joining,
                    'date_of_leaving' => $request->date_of_leaving,
                    'marital_status' => $request->marital_status,
                    'date_of_birth' => $request->date_of_birth,
                    'verification_status' => 0,
                    'salary' => $request->salary,
                    'created_by' => ApiHelper::get_adminid_from_token($request->api_token),
                    'updated_by' => ApiHelper::get_adminid_from_token($request->api_token),
                ]);


                if($request->salary){
                    
                    $currentDate = now();

                    // Format the current date as "Y-m-d"
                    $formattedDate = $currentDate->format('Y-m-d');

                HRMStaffRemuneration::create([
                        'staff_id' => $staff->staff_id,
                        'remuneration_type' => 1,
                        'remuneration_date' => $request->date_of_joining,
                        'remuneration_value' =>  $request->salary, 
                    ]); 
                }

                if ($request->account_name || $request->account_number || $request->bank_name || $request->bank_indetifier_coder || $request->bank_branch) {
                HRMStaffBankDetails::create([
                        'staff_id' => $staff->staff_id,
                        'account_name' => $request->account_name,
                        'account_number' =>  $request->account_number, 
                        'bank_name' =>  $request->bank_name, 
                        'bank_indetifier_coder' =>  $request->bank_indetifier_coder, 
                        'bank_branch' =>  $request->bank_branch,  
                    ]); 
                }

                if ($request->identity_proof) {
                    if(!empty($request->identity_proof)){

                    $extension = pathinfo($request->identity_proof, PATHINFO_EXTENSION);

                        $file_name = 'identity_proof' . uniqid() . '.' . $extension;
     
                        // Use Guzzle to fetch the image content
                        $client = new Client();

                        try {
                            $response = $client->get($request->identity_proof);
                            $imageData = $response->getBody()->getContents();

                            // Save the image to the storage folder
                            // Storage::disk('public')->put($file_name, $imageData);

                            Storage::put('tmp/' . $file_name, $imageData);

                            $res = StaffDocument::create([
                                'document_id' => 1,
                                'document_file' => 'tmp/'.$file_name,
                                'staff_id' => $staff->staff_id,
                            ]); 

                            // Return the URL or use it as needed 
                        } catch (\Exception $e) {
                            // Handle the exception (e.g., log it or return an error response) 
                            return ApiHelper::JSON_RESPONSE(false, [], 'Failed to fetch image content');
                        } 
                    }

                }

                if ($request->address_proof) {
                    if(!empty($request->address_proof)){

                    $extension = pathinfo($request->address_proof, PATHINFO_EXTENSION);

                        $file_name = 'address_proof' . uniqid() . '.' . $extension;
     
                        // Use Guzzle to fetch the image content
                        $client = new Client();

                        try {
                            $response = $client->get($request->address_proof);
                            $imageData = $response->getBody()->getContents();

                            // Save the image to the storage folder
                            // Storage::disk('public')->put($file_name, $imageData);
                             Storage::put('tmp/' . $file_name, $imageData);

                            $res = StaffDocument::create([
                                'document_id' => 2,
                                'document_file' => 'tmp/' .$file_name,
                                'staff_id' => $staff->staff_id,
                            ]); 

                            // Return the URL or use it as needed 
                        } catch (\Exception $e) {
                            // Handle the exception (e.g., log it or return an error response) 
                            return ApiHelper::JSON_RESPONSE(false, [], 'Failed to fetch image content');
                        } 
                    }

                }
                

                

 

               if ($request->street_address || $request->city || $request->state || $request->postcode || $request->countries_id || $request->phone_no) {
                    $staffAddress = StaffAddress::create([
                        'staff_id' => $staff->staff_id,
                        'address_type' => 1,
                        'street_address' => $request->street_address,
                        'city' => $request->city,
                        'state' => $request->state,
                        'postcode' => $request->postcode,
                        'countries_id' => $request->countries_id,
                        'phone_no' => $request->phone_no,
                    ]); 
                


                    if ($request->address_type) {
                        StaffAddress::create([
                            'staff_id' => $staff->staff_id,
                            'address_type' => 2,
                            'street_address' => $request->permanent_street_address,
                            'city' => $request->permanent_city,
                            'state' => $request->permanent_state,
                            'postcode' => $request->permanent_postcode,
                            'countries_id' => $request->permanent_countries_id,
                            'phone_no' => $request->permanent_phone_no,
                        ]); 
                    } 
                    // else {
                    //     $presentAdd = $staffAddress->replicate()->fill([
                    //         'address_type' => 2,
                    //     ]);
                    //     $presentAdd->save();
                    // }
                
                }



 
                    if (sizeof($request->company_name) > 0 || !empty($request->company_name)) {
               

                    foreach ($request->company_name as $key => $work) {
                        $doc_id = 0;
                         if ($request->company_designation[$key] || $request->company_address[$key] || $request->contact_name[$key] || $request->contact_email[$key] || $request->contact_phone[$key]) {
                          
                            StaffWorkExp::create([
                                'company_name' => $work ?? '',
                                'company_designation' => $request->company_designation[$key] ?? '',
                                'company_address' => $request->company_address[$key] ?? '',
                                'contact_name' => $request->contact_name[$key] ?? '',
                                'contact_email' => $request->contact_email[$key] ?? '',
                                'contact_phone' => $request->contact_phone[$key] ?? '',
                                'date_of_joining' => $request->work_date_of_joining[$key] ?? '',
                                'date_of_leaving' => $request->work_date_of_leaving[$key] ?? '',
                                'reason_for_leaving' => $request->reason_for_leaving[$key] ?? '',
                                'staff_doc_id' => $doc_id,
                                'staff_id' => $staff->staff_id,
                            ]); 
                        }
                    }
                }

                $education_id = $request->education_id ? $request->education_id : 0;
                $university_name = $request->university_name ? $request->university_name : 0;
                $admission_at = $request->admission_at ? $request->admission_at : 0;
                $passing_at = $request->passing_at ? $request->passing_at : 0;
                $education_document_type = $request->education_document_type ? $request->education_document_type : 0;
                $education_document = $request->education_document ? $request->education_document : 0;

             if ($education_document != 0 ) {
                foreach ($education_document as $key => $value) {

                    $doc_id = 0; 
                        if(!empty($request->education_document[$key])){
                            $extension = pathinfo($request->education_document[$key], PATHINFO_EXTENSION);

                            $file_name = 'profile' . uniqid() . '.' . $extension;
         
                            // Use Guzzle to fetch the image content
                            $client = new Client();
                            try {
                                $response = $client->get($request->education_document[$key]);
                                $imageData = $response->getBody()->getContents();

                                // Save the image to the storage folder
                                Storage::disk('public')->put($file_name, $imageData);

                                $res = StaffDocument::create([
                                    'document_id' => $request->education_document_type[$key] ?? 0,
                                    'document_file' => $file_name,
                                    'staff_id' => $staff->staff_id,
                                ]);
                                $doc_id = $res->staff_doc_id; 
 
                                // Return the URL or use it as needed 
                            } catch (\Exception $e) {
                                // Handle the exception (e.g., log it or return an error response) 
                                return ApiHelper::JSON_RESPONSE(false, [], 'Failed to fetch image content');
                            } 
                        }
                                    

                    StaffQualification::create([
                        'staff_id' => $staff->staff_id,
                        'university_name' => $request->university_name[$key] ?? 0,
                        'education_id' => $education_id[$key] ?? 0,
                        'admission_at' => $request->admission_at[$key] ?? 0,
                        'passing_at' => $request->passing_at[$key] ?? 0,
                        'staff_doc_id' => $doc_id,  
                    ]);
                }
            }
                

                return ApiHelper::JSON_RESPONSE(true, $user, 'SUCCESS_STAFF_ADD');
            }
      
    }

    public function edit(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $staff_details = Staff::find($request->staff_id);

        if ($staff_details != null) {

            $staff_details->staff_photo =
                !empty($staff_details->staff_photo) ? Storage::url($staff_details->staff_photo) : '';

            $staff_details->user = $staff_details->user;
            $staff_details->department = $staff_details->department;
            $staff_details->designation = $staff_details->designation;
            $staff_details->staff_address = $staff_details->staff_address;
            if (!empty($staff_details->staff_address)) {
                $staff_details->staff_address = $staff_details->staff_address->map(function ($address) {
                    $address->country = $address->country;
                    return $address;
                });
            }

            $staff_details->staff_document = $staff_details->staff_document;
            if (!empty($staff_details->staff_document)) {
                $staff_details->staff_document = $staff_details->staff_document->map(function ($doc) {
                    $doc->document_file = !empty($doc->document_file) ? Storage::url($doc->document_file) : '';
                    $doc->document_file_name = isset($doc->doc_info) ? $doc->doc_info->document_name : '';
                    $doc->document_file_type = (strpos($doc->document_file, ".png") || strpos($doc->document_file, ".jpg") || strpos($doc->document_file, ".gif")) ? 'image' : 'other';
                    return $doc;
                });
            }

            $staff_details->staff_qualification = $staff_details->staff_qualification;

            if (!empty($staff_details->staff_qualification)) {
                $staff_details->staff_qualification = $staff_details->staff_qualification->map(function ($quali) {
                    $quali->education = $quali->education;
                    return $quali;
                });
            }

            $staff_details->staff_experiance = $staff_details->staff_experiance;

            $staff_details->staff_remark = $staff_details->staff_remark;


            $staff_details->staff_remuneration = $staff_details->staff_remuneration;

            $staff_details->hrm_staff_bank_details = $staff_details->hrm_staff_bank_details;
            

            $document = Document::all();
            $designation = Designation::all();
            $department = Department::all();
            $country = Country::all();
            $education = Education::all();


            $attendReport = AttendenceReport::where('staff_id' , $request->staff_id)->get();

            $uniqueYears = $attendReport->flatMap(function ($report) {
                            return [\Carbon\Carbon::parse($report->clock_in_time)->format('Y')];
                        })->unique()->values()->toArray();

            $monthWiseData = []; 
            foreach($uniqueYears as $key=>$unique){
                $list = [];
                $total = [];
                $TP = $TL = $TPL = $TS = 0;
                 for($i=01; $i<=12; $i++){

                    $present = AttendenceReport::where('staff_id' , $request->staff_id)->whereMonth('clock_in_time' , $i)->whereYear('clock_in_time' , $unique)->where('status' , 'present')->count();

                    $staff_salary = Salary::where('salary_month' , $i)->where('salary_year' , $unique)->where('staff_id' , $request->staff_id)->first();


                    $TP += $present; 
                    $TL += $staff_salary->total_leave ?? 0;
                    $TPL += $staff_salary->paid_leave ?? 0;
                    $TS += $staff_salary->salary_amount ?? 0;


                    $arr = [ 
                        "present" => $present, 
                        "leave" => $staff_salary->total_leave ?? 0,
                        "paid_leave" => $staff_salary->paid_leave ?? "-",
                        "salaryAmt" => $staff_salary->salary_amount ?? "-",
                    ];
                      array_push($list , $arr);

                 }

                  
                 $Tarr = [  
                        "TP" => $TP,
                        "TL" => $TL,
                        "TPL" => $TPL,
                        "TS" => $TS
                    ];
                      array_push($total , $Tarr);
                     


                 $attend = [
                    "year" => $unique,
                    "list" => $list,
                    "total" => $total
                ];
                array_push($monthWiseData , $attend);
            }
 



            $res = [
                'staff_details' => $staff_details,
                'documentation' => $document,
                'designation' => $designation,
                'department' => $department,
                'country' => $country,
                'education' => $education,
                'monthWiseData' => $monthWiseData,
            ];


            return ApiHelper::JSON_RESPONSE(true, $res, '');
        } else
            return ApiHelper::JSON_RESPONSE(false, [], 'SOMETHING_WRONG');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        $staff_id = $request->staff_id;
        $sectionName = $request->updateSection;

        switch ($sectionName) {
            case 'workexp':

                $doc_id = 0;
                if (!empty($request->document)) {
                    // $imgNewLoc = str_replace("tempfolder", "StaffWorkExp", $request->document);
                    // Storage::move($request->document, $imgNewLoc);
                    


                    $extension = pathinfo($request->document, PATHINFO_EXTENSION);

                    $file_name = 'profile' . uniqid() . '.' . $extension;
 
                    // Use Guzzle to fetch the image content
                    $client = new Client();
                    try {
                        $response = $client->get($request->document);
                        $imageData = $response->getBody()->getContents();

                        // Save the image to the storage folder
                        Storage::disk('public')->put($file_name, $imageData);
 

                        // Return the URL or use it as needed 
                    } catch (\Exception $e) {
                        // Handle the exception (e.g., log it or return an error response) 
                        return ApiHelper::JSON_RESPONSE(false, [], 'Failed to fetch image content');
                    }


                    $res = StaffDocument::create(['document_id' => $request->document_type, 'document_file' => $file_name, 'staff_id' => $staff_id]);
                    $doc_id = $res->staff_doc_id;


                }

                $expdata = $request->only([
                    'company_name', 'company_designation', 'company_address', 'contact_name', 'contact_email', 'contact_phone', 'date_of_joining', 'date_of_leaving', 'reason_for_leaving', 'staff_id',
                ]);
                $expdata['staff_doc_id'] = $doc_id;

                $status =  ($request->updateType == 'new')
                    ? StaffWorkExp::create($expdata)
                    : StaffWorkExp::where('experience_id', $request->experience_id)->update($expdata);
                break;

            case 'education':

                $doc_id = 0;
                if (!empty($request->document)) {   

                    $extension = pathinfo($request->document, PATHINFO_EXTENSION);

                    $file_name = 'profile' . uniqid() . '.' . $extension;
 
                    // Use Guzzle to fetch the image content
                    $client = new Client();
                    try {
                        $response = $client->get($request->document);
                        $imageData = $response->getBody()->getContents();

                        // Save the image to the storage folder
                        Storage::disk('public')->put($file_name, $imageData);

                        // Get the URL for the uploaded image in the public storage folder
                        $imageUrl = asset('storage/' . $file_name);

                        // Return the URL or use it as needed 
                    } catch (\Exception $e) {
                        // Handle the exception (e.g., log it or return an error response) 
                        return ApiHelper::JSON_RESPONSE(false, [], 'Failed to fetch image content');
                    }



                    // $imgNewLoc = str_replace("tmp", "StaffEducation", $request->document);
                    // Storage::move($request->document, $imgNewLoc);
                    $res = StaffDocument::create(['document_id' => $request->staff_doc_id ?? 0, 'document_file' => $file_name, 'staff_id' => $staff_id]);
                    $doc_id = $res->staff_doc_id;
                }

                $expdata = $request->only(['staff_id', 'education_id', 'university_name', 'admission_at', 'passing_at']);
                $expdata['staff_doc_id'] = $request->staff_doc_id;

                $status = ($request->updateType == 'new')
                    ? StaffQualification::create($expdata)
                    : StaffQualification::where('qualification_id', $request->qualification_id)->update($expdata);
                break;

            case 'basic_info':

                $expdata = $request->except(['updateSection', 'api_token','staff_photo']);

                $status = Staff::where('staff_id', $staff_id)->update($expdata);
 

                $imageUrl = $request->staff_photo;
                if($imageUrl != '' || !empty($imageUrl)){
                    $extension = pathinfo($imageUrl, PATHINFO_EXTENSION);

                    $file_name = 'profile' . rand(999, 9999) . '.' . $extension;

                    // Use Guzzle to fetch the image content
                    $client = new Client();
                    try {
                        $response = $client->get($imageUrl);
                        $imageData = $response->getBody()->getContents();

                        // Save the image to the storage folder
                        Storage::disk('public')->put($file_name, $imageData);
 

                        // Return the URL or use it as needed 
                    } catch (\Exception $e) {
                        // Handle the exception (e.g., log it or return an error response) 
                        return ApiHelper::JSON_RESPONSE(false, [], 'Failed to fetch image content');
                    }

                    $status = Staff::where('staff_id', $staff_id)->update(['staff_photo' => $file_name]);
                }

                break;

            case 'address':
                $expdata = $request->except(['updateSection', 'updateType', 'api_token']);
                $status = StaffAddress::where('address_id', $request->address_id)->update($expdata);

                break;

            case 'ProfileImageUpdate':
                $filename = $request->file('fileInfo')->store("profile");
                $status = Staff::where('staff_id', $staff_id)->update(['staff_photo' => $filename]);
                break;

            default:
                $status = false;
                break;
        }
        if ($status)
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_STAFF_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(true, [], 'ERROR_STAFF_UPDATE');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $staff_id = $request->staff_id;
        $type = $request->type;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $staff = Staff::find($staff_id);

        if ($type == 'verification') {
            $staff->verification_status  = $staff->verification_status == 0 ? 1 : 0;
        } else {
            if ($staff->status == 1) {
                $staff->status  = 2;
                $staff->termination_reason = $request->termination_reason;

                StaffRemark::create([
                    'staff_id' => $staff_id,
                    'remark_type' => 4,
                    'remark_grade' => 0,
                    'remark_details' => $request->remark_details,
                    'updated_at' => date('Y-m-d'),
                ]);
            } else {
                $staff->status  = 1;
            }
        }

        $status = $staff->save();
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_STATUS_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_STATUS_UPDATE');
        }
    }

    public function verification(Request $request)
    {
        $api_token = $request->api_token;
        $staff_id = $request->staff_id;
        // $remark_id= $request->remark_id;
        // $type = $request->type;

        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus))
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        // $staff = Staff::find($staff_id);

        $staffRemark = StaffRemark::create([
            'remark_details' => $request->remark_details,
            'staff_id' => $request->staff_id,
            'remark_type'=> 2,
        ]);


        $staff = Staff::where('staff_id', $staff_id)->update([
            'verified_by' =>  $staffRemark->remark_id,
            'verification_status'=> 1,
            'verified_at' => date('Y-m-d'),
        ]);

        $staffRemark = $staff;

        if ($staffRemark) {
            return ApiHelper::JSON_RESPONSE(true, $staffRemark, 'SUCCESS_VERIFICATION_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_VERIFICATION_UPDATE');
        }
    }

    public function terminate(Request $request)
    {
        $api_token = $request->api_token;
        $staff_id = $request->staff_id;
        $staffRemark = StaffRemark::create([
            'remark_details' => $request->remark_details,
            'staff_id' => $request->staff_id,
            'remark_type' => 4,
        ]);

        $staff = Staff::find($staff_id);

        $staff->termination_reason = $request->termination_reason;
        $staff->date_of_leaving = $request->date_of_leaving;
        $staff->status = 2;
        $staff->rehire = $request->rehire;

        $staffRemark = $staff->save();
        if ($staffRemark) {
            return ApiHelper::JSON_RESPONSE(true, $staffRemark, 'SUCCESS_TERMINATE_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_TERMINATE_UPDATE');
        }
    }

    public function performance(Request $request)
    {
        $api_token = $request->api_token;
        $staff_id = $request->staff_id;
        $staffRemark = StaffRemark::create([
            'staff_id' => $request->staff_id,
            'remark_type' => 3,
            'remark_grade' => $request->grade,
            'remark_details' => $request->remark_details,
        ]);

        // $staff = Staff::find($staff_id);

        // $staff->termination_reason = $request->termination_reason;
        // $staff->date_of_leaving = $request->date_of_leaving;
        // $staff->status = 2;
        // $staff->rehire = $request->rehire;

        // $staffRemark = $staff->save();
        if ($staffRemark) {
            return ApiHelper::JSON_RESPONSE(true, $staffRemark, 'ADD_SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_UPDATE');
        }
    }

    public function remunerationAdd(Request $request)
    {
        $api_token = $request->api_token;
        $staff_id = $request->staff_id; 

        $staffRemuneration = HRMStaffRemuneration::create([
            'staff_id' => $request->staff_id,
            'remuneration_type' => $request->remuneration_type,
            'remuneration_date' => $request->remuneration_date,
            'remuneration_value' => $request->remuneration_value, 
        ]);

        // Staff::where('staff_id' , $request->staff_id)->update(['salary' => $request->remuneration_value]);

        
        if ($staffRemuneration) {
            return ApiHelper::JSON_RESPONSE(true, $staffRemuneration, 'ADD_SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_UPDATE');
        }
    }


   

    

    public function performEdit(Request $request){

        $api_token = $request->api_token;
        $performance_id = $request->performance_id;

        $record = StaffRemark::find($performance_id);

         if ($record) {
            return ApiHelper::JSON_RESPONSE(true, $record, '');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], '');
        }
    }


    public function remunerationEdit(Request $request){

        $api_token = $request->api_token;
        $remuneration_id = $request->remuneration_id;

        $record = HRMStaffRemuneration::find($remuneration_id);

         if ($record) {
            return ApiHelper::JSON_RESPONSE(true, $record, '');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], '');
        }
    }
    
    public function performanceUpdate(Request $request)
    {
        $api_token = $request->api_token;
        $staff_id = $request->staff_id;
        $remark_id = $request->remark_id;

        

        $remark = StaffRemark::find($remark_id);

        if ($remark) { 

            $remark->update([
                'staff_id' => $staff_id,
                'remark_type' => 3,
                'remark_grade' => $request->grade,
                'remark_details' => $request->remark_details,
            ]);
        }

         
        if ($remark) {
            return ApiHelper::JSON_RESPONSE(true, $remark, 'UPDATE_SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_ADD_SUCCESS');
        }
    }

    
    public function remunerationUpdate(Request $request)
    {
  

        $api_token = $request->api_token;
        $staff_id = $request->staff_id;
        $remuneration_id = $request->remuneration_id;

        

        $remark = HRMStaffRemuneration::find($remuneration_id);

        if ($remark) { 

            $remark->update([
                'staff_id' => $request->staff_id,
                'remuneration_type' => $request->remuneration_type,
                'remuneration_date' => $request->remuneration_date,
                'remuneration_value' => $request->remuneration_value, 
            ]); 
        }

        // Staff::where('staff_id' , $request->staff_id)->update(['salary' => $request->remuneration_value]);

         
        if ($remark) {
            return ApiHelper::JSON_RESPONSE(true, $remark, 'UPDATE_SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_ADD_SUCCESS');
        }
    }


     public function bankDetails(Request $request)
    {
        $api_token = $request->api_token;
        $staff_id = $request->staff_id; 

        $stafDetails = HRMStaffBankDetails::create([
            "staff_id" => $request->staff_id,
            "account_name" => $request->account_name,
            "account_number" => $request->account_number,
            "bank_name" => $request->bank_name,
            "bank_indetifier_coder" => $request->bank_indetifier_coder,
            "bank_branch" => $request->bank_branch,
        ]);

        
        if ($stafDetails) {
            return ApiHelper::JSON_RESPONSE(true, $stafDetails, 'ADD_SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_UPDATE');
        }
    }

    public function bankDetailsUpdate(Request $request)
    {
  
        $staff_id = $request->staff_id;
        $account_name = $request->account_name;
        $account_number = $request->account_number;
        $bank_name = $request->bank_name;
        $bank_indetifier_coder = $request->bank_indetifier_coder;
        $bank_branch = $request->bank_branch;
        $bank_details_id = $request->bank_details_id;

        

        $bank_details = HRMStaffBankDetails::find($bank_details_id);

        if ($bank_details) { 

            $bank_details->update([
                'staff_id' => $request->staff_id, 
                "account_name" => $request->account_name,
                "account_number" => $request->account_number,
                "bank_name" => $request->bank_name,
                "bank_indetifier_coder" => $request->bank_indetifier_coder,
                "bank_branch" => $request->bank_branch, 
            ]);
        }

         
        if ($bank_details) {
            return ApiHelper::JSON_RESPONSE(true, $bank_details, 'UPDATE_SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_ADD_SUCCESS');
        }
    }

    public function bankDetailsEdit(Request $request){

        $api_token = $request->api_token;
        $bank_details_id = $request->bank_details_id;

        $record = HRMStaffBankDetails::find($bank_details_id);

         if ($record) {
            return ApiHelper::JSON_RESPONSE(true, $record, '');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], '');
        }
    }

    public function impotStore(Request $request){

          

        $import_file = $request->file('import_file');


        if (!empty($import_file)) {

            Excel::import(new StaffImport(),  $request->file('import_file'));

            return ApiHelper::JSON_RESPONSE(true, [], 'ADD_SUCCESS');

            
        }

    }


    
}
