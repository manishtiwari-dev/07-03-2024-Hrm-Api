<?php

namespace Modules\HRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper; 
use Validator;
use Carbon\Carbon; 
use Modules\HRM\Models\Salary;
use Modules\HRM\Models\Staff;
use DateTime;
use Modules\HRM\Models\AttendenceReport;
use Modules\HRM\Exports\ReportsExport;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Excel as ExcelExcel;
use Illuminate\Support\Facades\Storage;

class HRMReportsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public $page = 'reports';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {

        $month =  !empty($request->month) ? $request->month : now()->month;
        $year = !empty($request->year) ? $request->year : now()->year; 

        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);

        


        $staff = Staff::with('salaryAmt');

        if ($request->user_id != 'all') {
            $staff = $staff->where('staff_id', $request->user_id);
        }
 
 

        $stafflist = $staff->get();


        $monthWiseData = []; 
        $tstaff = [];
            foreach($stafflist as $staff){ 
                $list = [];
                $total = [];
                 $TP = $TL = $TPL = $TS = 0;
                for ($month = 1; $month <= 12; $month++) { 
                    $present = AttendenceReport::where('staff_id' , $staff->staff_id)->whereMonth('clock_in_time' , $month)->whereYear('clock_in_time' , $year)->where('status' , 'present')->count();
                    $absent = AttendenceReport::where('staff_id' , $staff->staff_id)->whereMonth('clock_in_time' , $month)->whereYear('clock_in_time' , $year)->where('status' , 'absent')->count();
                    $staff_salary = Salary::where('salary_month' , $month)->where('salary_year' , $year)->where('staff_id' , $staff->staff_id)->first();

 
                    $date = Carbon::createFromDate($year, $month, 1);
                    $totalDays = $date->daysInMonth;

                    $TP += $present; 
                    $TL += $staff_salary->total_leave ?? 0;
                    $TPL += $staff_salary->paid_leave ?? 0;
                    $TS += $staff_salary->salary_amount ?? 0;

 
                    $arr = [ 
                        "attend" => $present,
                        "leave" => $staff_salary->total_leave ?? 0,
                        "paid_leave" => $staff_salary->paid_leave ?? "-",
                        "salaryAmt" => $staff_salary->salary_amount ?? "-",
                    ];
                      array_push($list , $arr);
                }

                $Tarr = [  
                        "TP" => $TP,
                        "TL" => $TL,
                        "TPL" => $TPL,
                        "TS" => $TS
                    ];
                      array_push($total , $Tarr);

                $attend = [
                    "staff_name" => $staff->staff_name,
                    "list" => $list,
                    "total" => $total
                ];
                array_push($monthWiseData , $attend);
 
            }         
         

        $res = [  
            "month" =>$month,
            "year" => $year,
            "monthWiseData" => $monthWiseData,
            "stafflist" => $stafflist,  
        ];
              return ApiHelper::JSON_RESPONSE(true, $res, '');
      
    }


    public function reportExport(Request $request){

        $filters = [

        ];
 
        $date = Carbon::now(); // Current date and time
        $formattedDate = $date->format('Y-m-d');
 
        $file_name = "report " . $formattedDate . ".xlsx";

        $data = Excel::store(new ReportsExport(), $file_name);

        $url = Storage::path($file_name);

        
        return ApiHelper::JSON_RESPONSE(true, $url, '');

    }
 

    
}
