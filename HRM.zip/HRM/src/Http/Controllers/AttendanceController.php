<?php

namespace Modules\HRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\HRM\Models\Attendance;
use Illuminate\Support\Str;
use Validator;
use Modules\HRM\Models\AttendenceReport;
use Modules\HRM\Models\Department;
use Modules\CRM\Models\CRMCustomer;
use Carbon\Carbon;
use Modules\HRM\Models\Staff;
use App\Models\User;
use Modules\HRM\Models\Holiday;
use Modules\HRM\Models\LeaveType;
use Modules\HRM\Models\Leave;
use Modules\HRM\Exports\ExportAttendance;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Excel as ExcelExcel;
use Illuminate\Support\Facades\Storage;

use DB;

class AttendanceController extends Controller
{
    public $timezone = 'UTC';
    public $page = 'attendance';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $employees = Staff::with(
            [
                'attend' => function ($query) use ($request) {
                    $query->whereRaw('MONTH(hrm_attendances.clock_in_time) = ?', [$request->month])
                        ->whereRaw('YEAR(hrm_attendances.clock_in_time) = ?', [$request->year])
                        ->whereRaw('status=?', 'present');
                },

                'leaves' => function ($query) use ($request) {
                    $query->whereRaw('MONTH(hrm_leaves.leave_date) = ?', [$request->month])
                        ->whereRaw('YEAR(hrm_leaves.leave_date) = ?', [$request->year])
                        ->where('status', 'approved');
                }
            ]

        );

        if ($request->user_id != 'all') {
            $employees = $employees->where('staff_id', $request->user_id);
        }



        $employees = $employees->get();


        $holidays = Holiday::whereRaw('MONTH(hrm_holidays.date) = ?', [$request->month])->whereRaw('YEAR(hrm_holidays.date) = ?', [$request->year])->get();


        $final = [];
        $holidayOccasions = [];

        $daysInMonth = Carbon::parse('01-' . $request->month . '-' . $request->year)->daysInMonth;
        $now = Carbon::now();
        $requestedDate = Carbon::parse(Carbon::parse('01-' . $request->month . '-' . $request->year))->endOfMonth();


        foreach ($employees as $employee) {
            $employees_name = $employee->staff_name;

            $dataBeforeJoin = null;

            $dataTillToday = array_fill(1, $now->copy()->format('d'), 'Absent');

            if (($now->copy()->format('d') != $daysInMonth) && !$requestedDate->isPast()) {
                $dataFromTomorrow = array_fill($now->copy()->addDay()->format('d'), ((int)$daysInMonth - (int)$now->copy()->format('d')), '-');
            } else {
                $dataFromTomorrow = array_fill($now->copy()->addDay()->format('d'), ((int)$daysInMonth - (int)$now->copy()->format('d')), 'Absent');
            }


            $final[$employee->staff_id . '#' . $employee->staff_name] = array_replace($dataTillToday, $dataFromTomorrow);


            if (!empty($employee->attend)) {
                foreach ($employee->attend as $attendance) {
                    $final[$employee->staff_id . '#' . $employee->staff_name][Carbon::parse($attendance->clock_in_time)->day] = 'Present';
                }
            }

            if (Carbon::parse('01-' . $request->month . '-' . $request->year)->isFuture()) {
                $dataBeforeJoin = array_fill(1, $daysInMonth, '-');
            }

            if (!is_null($dataBeforeJoin)) {
                $final[$employee->staff_id . '#' . $employee->staff_name] = array_replace($final[$employee->staff_id . '#' . $employee->staff_name], $dataBeforeJoin);
            }

            foreach ($employee->leaves as $leave) {

                $final[$employee->staff_id . '#' . $employee->staff_name][Carbon::parse($leave->leave_date)->day] = 'Leave';
            }



            foreach ($holidays as $holiday) {

                if ($final[$employee->staff_id . '#' . $employee->staff_name][Carbon::parse($holiday->date)->day] == 'Absent' || $final[$employee->staff_id . '#' . $employee->staff_name][Carbon::parse($holiday->date)->day] == '-') {
                    $final[$employee->staff_id . '#' . $employee->staff_name][Carbon::parse($holiday->date)->day] = 'Holiday';
                    $holidayOccasions[Carbon::parse($holiday->date)->day] = $holiday->occassion;
                }
            }
        }
        $req_month = $request->month;
        $req_year = $request->year;
        $month = date('m');
        $now = Carbon::now();
        $year = $now->format('Y');
        $days = Carbon::now()->month($month)->daysInMonth;
        $user_data = Staff::all();


        $res = [
            'employeeAttendence' => $final,
            'daysInMonth' => $daysInMonth,
            'month' => $month,
            'year' => $year,
            'days' => $days,
            'user_data' => $user_data,
            'req_month' => $req_month,
            'req_year' => $req_year
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function attendData(Request $request)
    {
        $this->index();
        $month = date('m');

        $data_list = User::all();


        $now = Carbon::now();
        $year = $now->format('Y');
        $days = Carbon::now()->month($month)->daysInMonth;
        $user_data = User::all();


        $res = [
            'data_list' => $data_list,
            'year' => $year,
            'month' => $month,
            'days' => $days,
            'user_data' => $user_data,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function checkIn(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }
        $clientIP = $request->ip();
        $user_id = $request->user_id;
        $date =  Carbon::createFromFormat('m/d/Y', $request->attendence_date)->format('Y-m-d');
        $year = $request->year;
        $month = $request->month;

        $clock_In = ($date . ' ' . $request->clock_in_time);

        $clock_Out = ($date . ' ' . $request->clock_out_time);

        $dayCount = date('t', strtotime("01" . '-' . $month . '-' . $year));
        // in case of july 2022 it will be 31  

        $holidays = Holiday::all();
        $holiArr = [];
        foreach ($holidays as $holiday) {
            array_push($holiArr, $holiday->date);
        }

        $currentDate = Carbon::now();

        $curDate = $currentDate->format('Y-m-d');
        $selected_clock = [];
        for ($i = 1; $i <= $dayCount; $i++) {
            $days = Carbon::create($year, $month, $i);
            // if ($days->dayOfWeek !== Carbon::SUNDAY) {
            //     $clockIn = ($days . ' ' . $request->clock_in_time);
            //     $clockOut = ($days . ' ' . $request->clock_out_time);

            //     array_push($selected_clock, [
            //         "clockIn" => $clockIn,
            //         "clockOut" => $clockOut,
            //         "leave_date" => $days
            //     ]);
            // }

            $dateFormat = Carbon::parse($days)->format('Y-m-d');
            if (!in_array($dateFormat, $holiArr)) {
                $clockIn = ($dateFormat . ' ' . $request->clock_in_time);
                $clockOut = ($dateFormat . ' ' . $request->clock_out_time);

                array_push($selected_clock, [
                    "date" => $dateFormat,
                    "clockIn" => $clockIn,
                    "clockOut" => $clockOut,
                    "leave_date" => $days
                ]);
            }
        }
        $monthlyAttend = '';
        foreach ($user_id as  $key => $value) {

            $joining = Staff::where('staff_id', $value)->first();

            if ($request->mark_attendence == '1') {
                foreach ($selected_clock as $clockKey) {

                    $leave =  Leave::where('leave_date', $clockKey['leave_date'])->where('status', 'approved')->where('staff_id', $value)->first();

                    $attendanceData = AttendenceReport::whereDate('clock_in_time', $clockKey['leave_date'])->where('staff_id', $value)->first();

                    $clock_in_time = $clockKey['clockIn'];
                    $clock_out_time = $clockKey['clockOut'];

                    if (!empty($joining->date_of_leaving)) {

                        if ($joining->date_of_joining <= $clockKey['date'] && $clockKey['date'] <= $joining->date_of_leaving) {

                            if (empty($leave) && empty($attendanceData)) {
                                $monthlyAttend = AttendenceReport::create(

                                    [
                                        'staff_id' => $value,
                                        'clock_in_time' => $clock_in_time,
                                        'clock_out_time' => $clock_out_time,
                                        'working_from' => $request->working_from,
                                        'late' => $request->late,
                                        'half_day' => $request->half_day,
                                        'clock_in_ip' => $clientIP,
                                        'clock_out_ip' => $clientIP,
                                        'created_by' => ApiHelper::get_adminid_from_token($api_token),
                                    ]
                                );
                            }
                        }
                    } else {

                        if ($joining->date_of_joining <=  $clockKey['date']) {
                            if (empty($leave) && empty($attendanceData)) {
                                $monthlyAttend = AttendenceReport::create(

                                    [
                                        'staff_id' => $value,
                                        'clock_in_time' => $clock_in_time,
                                        'clock_out_time' => $clock_out_time,
                                        'working_from' => $request->working_from,
                                        'late' => $request->late,
                                        'half_day' => $request->half_day,
                                        'clock_in_ip' => $clientIP,
                                        'clock_out_ip' => $clientIP,
                                        'created_by' => ApiHelper::get_adminid_from_token($api_token),
                                    ]
                                );
                            }
                        }
                    }
                }
            }


            if ($request->mark_attendence == '0') {

                $leave =  Leave::where('leave_date', $date)->where('status', 'approved')->where('staff_id', $value)->first();

                $attendanceData = AttendenceReport::whereDate('clock_in_time', $clockKey['leave_date'])->where('staff_id', $value)->first();

                if (empty($leave) && empty($attendanceData)) {
                    foreach ($user_id as $key => $value) {
                        $monthlyAttend = AttendenceReport::create([
                            'staff_id' => $value,
                            'clock_in_time' => $clock_In,
                            'clock_out_time' => $clock_Out,
                            'working_from' => $request->working_from,
                            'late' => $request->late,
                            'half_day' => $request->half_day,
                            'clock_in_ip' => $clientIP,
                            'clock_out_ip' => $clientIP,
                            'created_by' => ApiHelper::get_adminid_from_token($api_token),
                        ]);
                    }
                }
            }
        }


        if ($monthlyAttend) {
            return ApiHelper::JSON_RESPONSE(true, $monthlyAttend, ' SUCCESS_TODAY_ATTENDANCE_FOUND');
        } else {
            return ApiHelper::JSON_RESPONSE(false, $monthlyAttend, 'ERROR_TODAY_ATTENDANCE_FOUND');
        }
    }

    public function create(Request $request)
    {
        $api_token = $request->api_token;
        $department_id = $request->department_id;

        $dept_list = Department::all();


        $now = Carbon::now();
        $year = $now->format('Y');
        $list = LeaveType::all();
        $user_list = Staff::all();



        $res = [

            'dept_list' => $dept_list,
            'user_list' => $user_list,
            'year' => $year,
            'leave_type' => $list,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function select_dept(Request $request)
    {
        $api_token = $request->api_token;
        $department_id = $request->department_id;

        $dept_list = Department::all();


        $user_list = Staff::where('department_id', $department_id)->get();

        $res = [


            'user_list' => $user_list,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function storeClockIn(Request $request)
    {
        $api_token = $request->api_token;

        $date =  date_default_timezone_set("Asia/Calcutta");
        $nowTime = date('Y-m-d h:i:s');
        $now = Carbon::now();
        $user_id = ApiHelper::get_user_id_from_token($api_token);


        $clockInCount = AttendenceReport::getTotalUserClockIn($now->format('Y-m-d'),  $user_id);
        $currentTimestamp = $now->setTimezone('UTC');
        $currentTimestamp = $currentTimestamp->timestamp;




        $approve_leave = Leave::where(['staff_id' => $user_id, 'leave_date' => $now->format('Y-m-d'), 'status' => 'approved'])->first();

        if (empty($approve_leave)) {
            $attendance = new AttendenceReport();
            $attendance->staff_id = $user_id;
            $attendance->clock_in_time = $nowTime;
            $attendance->clock_in_ip = request()->ip();
            $attendance->working_from = $request->working_from;
            $currentLatitude = $request->currentLatitude;
            $currentLongitude = $request->currentLongitude;
            $attendance->save();

            $currentClockIn = AttendenceReport::where(DB::raw('DATE(clock_in_time)'), now()->format('Y-m-d'))
                ->where('staff_id', $user_id)->whereNull('clock_out_time')->first();


            return ApiHelper::JSON_RESPONSE(true, $currentClockIn, 'Attendence Saved Successfully');
        } else {
            return ApiHelper::JSON_RESPONSE(true, [], 'You have already approved leave for today');
        }
    }

    public function updateClockIn(Request $request)
    {
        $api_token = $request->api_token;

        $date =  date_default_timezone_set("Asia/Calcutta");
        $now = date('Y-m-d h:i:s');
        $user_id = ApiHelper::get_user_id_from_token($api_token);


        $attendance = AttendenceReport::findOrFail($request->id);


        $attendance->clock_out_time = $now;
        $attendance->clock_out_ip = request()->ip();
        $attendance->save();

        $currentClockIn = AttendenceReport::where(DB::raw('DATE(clock_in_time)'), now()->format('Y-m-d'))
            ->where('staff_id',   $user_id)->first();

        return ApiHelper::JSON_RESPONSE(true, $currentClockIn, 'Attendence Saved Successfully');
    }


    public function exportAttendance(Request $request)
    {
        // Validate  page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $filters = [
            'staff' => $request->staff,
            'month' => $request->month,
            'year' => $request->year,
        ];

        $date = Carbon::now(); // Current date and time
        $formattedDate = $date->format('Y-m-d');

        $file_name = "attendance " . $formattedDate . ".xlsx";

        $data = Excel::store(new ExportAttendance($filters), $file_name);

        $url = Storage::path($file_name);


        return ApiHelper::JSON_RESPONSE(true, $url, '');
    }

    public function attendDetails(Request $request)
    {

        // Validate  page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $attendance = AttendenceReport::whereDay('clock_in_time', $request->date)->whereMonth('clock_in_time', $request->req_month)->whereYear('clock_in_time', $request->req_year)->where('staff_id', $request->staff_id)->first();


        $res = [
            'attendance' => $attendance,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function attendUpdate(Request $request)
    {

        // Validate  page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $clockIn =  $request->mart_attend_date . ' ' . $request->clock_in . ':00';
        $clockOut =  $request->mart_attend_date . ' ' . $request->clock_out . ':00';

        $record = AttendenceReport::find($request->attend_id);
        $record->clock_in_time = $clockIn;
        $record->clock_out_time =  $clockOut;
        $record->clock_in_ip =  $request->clock_in_ip;
        $record->clock_out_ip =  $request->clock_out_ip;
        $record->working_from =  $request->working_from;
        $record->late =  $request->late;
        $record->half_day  = $request->half_day;
        $record->status  = $request->status;
        $record->update();

        return ApiHelper::JSON_RESPONSE(true, $record, 'UPDATE_SUCCESS');
    }
}
