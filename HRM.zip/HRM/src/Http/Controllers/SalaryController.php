<?php

namespace Modules\HRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use Illuminate\Support\Str;
use Validator;
use Modules\HRM\Models\Salary;
use Modules\HRM\Models\Staff;
use Modules\HRM\Models\AttendenceReport;
use Modules\HRM\Models\HRMStaffRemuneration;
use Carbon\Carbon;
use Modules\HRM\Exports\ExportSalary;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Excel as ExcelExcel;
use Illuminate\Support\Facades\Storage;


class SalaryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public $page = 'hrm-salary';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        // get all request val
        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;


        $salary = Salary::with(['staff', 'remuneration' => function ($query) use ($request) {
            $query->whereYear('remuneration_date', $request->year)
                ->whereMonth('remuneration_date', $request->month);
        }]);

        if ($request->user_id != 'all') {
            $salary = $salary->where('staff_id', $request->user_id);
        }

        if ($request->month != 'all') {
            $salary = $salary->where('salary_month', $request->month);
        }

        if ($request->year != 'all') {
            $salary = $salary->where('salary_year', $request->year);
        }

        $salarylist = $salary->get();

        // $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;      

        // $data_count = $salary->count(); // get total count

        // $salarylist = $salary->skip($skip)->take($perPage)->get();

        $month = date('m');
        $now = Carbon::now();
        $year = $now->format('Y');
        $days = Carbon::now()->month($month)->daysInMonth;
        $user_data = Staff::all();

        $res = [
            'salarylist' => $salarylist,
            'month' => $month,
            'year' => $year,
            'days' => $days,
            'user_data' => $user_data
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $api_token = $request->api_token;
        $stafflist = Staff::all();

        $res = [
            'stafflist' => $stafflist,

        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $salary = new Salary();
        $salary->staff_id = $request->employee;
        $salary->salary_month = $request->month;
        $salary->salary_year = $request->year;
        $salary->salary_amount = $request->amount;
        $salary->payment_date =  Carbon::createFromFormat('m/d/Y', $request->payment_date)->format(' Y-m-d');
        $salary->payment_status = $request->payment_status;
        $salary->save();

        return ApiHelper::JSON_RESPONSE(true, [], 'ADD_SUCCESS');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $stafflist = Staff::all();
        $salary = Salary::find($request->salary_id);

        $res = [
            'stafflist' => $stafflist,
            'salary' => $salary,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $salary = Salary::find($request->salary_id);
        $salary->staff_id = $request->employee;
        $salary->total_days = $request->total_days;
        $salary->total_leave = $request->total_leave;
        $salary->paid_leave = $request->paid_leave;
        $salary->paid_days = $request->paid_days;
        $salary->salary_month = $request->month;
        $salary->salary_year = $request->year;
        $salary->salary_amount = $request->net_salary;
        $salary->payment_date = Carbon::createFromFormat('m/d/Y', $request->payment_date)->format(' Y-m-d');;
        $salary->payment_status = $request->payment_status;
        $salary->update();

        return ApiHelper::JSON_RESPONSE(true, [], 'UPDATE_SUCCESS');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function generateSalary(Request $request)
    {
        $res = [];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function generateSalarySection(Request $request)
    {

        $now = Carbon::now();
        $startOfMonth = Carbon::createFromFormat('d-m-Y', '01-' . $request->month . '-' . $request->year)->startOfMonth();
        $endOfMonth = Carbon::parse($startOfMonth)->endOfMonth();
        $daysInMonth = $startOfMonth->daysInMonth;

        $attendances = config('dbtable.common_hrm_attendances');
        $staff = config('dbtable.common_staffs');
        $leaves = config('dbtable.common_leave');


        $employees = Staff::with([
            'attend' => function ($query) use ($request, $attendances) {
                $query->whereRaw('MONTH(' . $attendances . '.clock_in_time) = ?', [$request->month])
                    ->whereRaw('YEAR(' . $attendances . '.clock_in_time) = ?', [$request->year])
                    ->whereRaw('status=?', 'present');
            },
            'leaves' => function ($query) use ($request, $leaves) {
                $query->whereRaw('MONTH(' . $leaves . '.leave_date) = ?', [$request->month])
                    ->whereRaw('YEAR(' . $leaves . '.leave_date) = ?', [$request->year])
                    ->where('status', '!=', 'rejected');
            }
        ])->leftJoin($attendances, $attendances . '.staff_id', '=', $staff . '.staff_id')
            ->select($staff . '.staff_id', $staff . '.staff_name', $staff . '.staff_email', $staff . '.created_at',   $staff . '.salary', $staff . '.date_of_joining', $staff . '.date_of_leaving');

        $employees = $employees->get();



        $attendance = AttendenceReport::whereMonth('clock_in_time', $request->month)->whereYear('clock_in_time', $request->year)->first();

        if (empty($attendance)) {
            return ApiHelper::JSON_RESPONSE(false, $attendance, 'No attendance record available');
        }


        $record_update = 0;
        foreach ($employees as $employee) {


            //START CALCULATION OF WORKING DAYS
            $joining_date = $employee->date_of_joining;
            $last_date = $employee->date_of_leaving;

            $joining_month = date('M', strtotime($joining_date));
            $joining_year = date('Y', strtotime($joining_date));

            $last_date_month = date('M', strtotime($last_date));
            $last_date_year = date('Y', strtotime($last_date));


            if (($joining_month == $last_date_month) &&  ($joining_year == $last_date_year)) {
                $joining_date = Carbon::parse($joining_date);
                $days = $joining_date->diffInDays($last_date); // diff between 1st_date_of_month and last_date

                $working_days = $days + 1;
            } else if ($joining_date >= $startOfMonth && $joining_date <= $endOfMonth) {

                $joining_date = Carbon::parse($joining_date);
                $days = $joining_date->diffInDays($endOfMonth); //diff between joining_date and last_date_of_month
                //END MONTH

                $working_days = $days + 1;
            } else if ($last_date >= $startOfMonth && $last_date <= $endOfMonth) {

                $startOfMonth = Carbon::parse($startOfMonth);
                $days = $startOfMonth->diffInDays($last_date); // diff between 1st_date_of_month and last_date

                $working_days = $days + 1;

                // IF JOINING MONTH & END MONTH SAME
            } else {
                $working_days = $daysInMonth;
            }



            //JOINING MONTH
            // if ($joining_date >= $startOfMonth && $joining_date <= $endOfMonth) {

            //     $joining_date = Carbon::parse($joining_date);


            //     if(!empty($employee->date_of_leaving)){
            //         if($employee->date_of_leaving >= $endOfMonth){
            //             $workLeave = $joining_date->diffInDays($endOfMonth);
            //         }else{
            //              $workLeave = $joining_date->diffInDays($employee->date_of_leaving);
            //         }

            //         $working_days = $workLeave+1;

            //     }else{

            //         $working = $joining_date->diffInDays($endOfMonth); 
            //         $working_days = $working+1; 
            //     }

            // } else if ($last_date >= $startOfMonth && $last_date <= $endOfMonth) {

            //     $startOfMonth = Carbon::parse($startOfMonth);
            //     $working = $startOfMonth->diffInDays($last_date);  
            //     $working_days = $working+1;

            //     // IF JOINING MONTH & END MONTH SAME
            // } else if (($joining_month == $last_date_month) &&  ($joining_year == $last_date_year)) {

            //     $joining_date = Carbon::parse($joining_date);
            //     $working = $joining_date->diffInDays($last_date);  

            //     $days = $working+1;

            //     if(!empty($employee->date_of_leaving)){
            //         $workLeave = $joining_date->diffInDays($employee->date_of_leaving);
            //         $working_days = $workLeave+1;
            //     }else{
            //          $working_days = $working+1;
            //     }

            // } else {
            //     $working_days = $daysInMonth;
            // }


            $leave_taken = $employee->leaves->where('status', 'approved')->count();

            $empSalary = HRMStaffRemuneration::whereMonth('remuneration_date', $request->month)->whereYear('remuneration_date', $request->year)->first();
            if (!empty($empSalary)) {

                $paid_leave = $employee->leaves->where('paid', 1)->count();
                $no_of_paid_days = $working_days - $leave_taken + $paid_leave;
                $gross_salary = ($empSalary->remuneration_value / $daysInMonth) * $no_of_paid_days;

                $deduction = $empSalary->remuneration_value - $gross_salary;


                $emp_attend = [];
                foreach ($employee->attend as $attendance) {
                    $attend = $attendance->staff_id;
                    array_push($emp_attend, $attend);
                }


                if (!empty($employee->staff_id)  && in_array($employee->staff_id, $emp_attend)) {



                    $salary = Salary::updateOrCreate(
                        [
                            'staff_id' => $employee->staff_id,
                            'salary_month' => $request->month,
                            'salary_year' => $request->year
                        ],
                        [
                            'staff_id' => $employee->staff_id,
                            'total_days' => $daysInMonth,
                            'total_leave' => $leave_taken,
                            'paid_leave' => $paid_leave,
                            'paid_days' => $no_of_paid_days,
                            'salary_month' =>  $request->month,
                            'salary_year' => $request->year,
                            'salary_amount' => $gross_salary,
                            'payment_status' => 0,

                        ]
                    );

                    $record_update++;
                }
            }
        }

        return ApiHelper::JSON_RESPONSE(true, [], 'SALARY_GENERATE_SUCCESS');
    }

    public function changeStatus(Request $request)
    {
        $salary =  Salary::find($request->salary_id);
        $salary->payment_date = Carbon::now();
        $salary->payment_status = $request->status;
        $salary->update();

        return ApiHelper::JSON_RESPONSE(true, $salary, 'SUCCESS_STATUS_UPDATE');
    }

    public function exportSalary(Request $request)
    {

        $filters = [
            'user_id' => $request->user_id,
            'month' => $request->month,
            'year' => $request->year,
        ];

        $date = Carbon::now(); // Current date and time
        $formattedDate = $date->format('Y-m-d');

        $file_name = "salary-generate " . $formattedDate . ".xlsx";

        $data = Excel::store(new ExportSalary($filters), $file_name);

        $url = Storage::path($file_name);


        return ApiHelper::JSON_RESPONSE(true, $url, '');
    }
}
