<?php

namespace Modules\HRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use App\Models\User;
use Modules\HRM\Models\Education;
use Illuminate\Support\Str;
use Validator;
use Auth;

class EducationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public $page = 'hrm-setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';



    public function store(Request $request)
    {
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $validator = Validator::make($request->all(), [
            'education_name' => 'required',
        ], [
            'education_name.required' => 'EDUCATION_NAME_REQUIRED',
        ]);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $educationUnquie = Education::where('education_name', $request->education_name)->first();
        if (!empty($educationUnquie)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'ADD_UNIQUE_EDUCATION');
        }


        $user_id = ApiHelper::get_adminid_from_token($api_token);

        $Insert = $request->only('education_name');
        $Insert['created_by'] = $user_id;

        $res = Education::create($Insert);
        if ($res)
            return ApiHelper::JSON_RESPONSE(true, $res->id, 'ADD_SUCCESS');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_EDUCATION_ADD');
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $data_list = Education::where('education_id', $request->education_id)->first();
        return ApiHelper::JSON_RESPONSE(true, $data_list, '');
    }

    public function update(Request $request)
    {
        $api_token = $request->api_token;
        $education_id = $request->education_id;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $validator = Validator::make($request->all(), [
            'education_name' => 'required',
        ], [
            'education_name.required' => 'EDUCATION_REQUIRED',
            'education_name.unique' => 'EDUCATION_UNIQUE_REQUIRED',
        ]);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());



        $Insert = $request->only('education_name');

        $res = Education::where('education_id', $education_id)->update($Insert);

        if ($res) {
            return ApiHelper::JSON_RESPONSE(true, $res, 'UPDATE_SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_EDUCATION_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        $education_id = $request->education_id;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }
        $status = Education::where('education_id', $education_id)->delete();
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'DELETE_SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_EDUCATION_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $education_id = $request->education_id;
        $sub_data = Education::find($education_id);
        $sub_data->status = $request->status;
        $sub_data->save();

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }
}
