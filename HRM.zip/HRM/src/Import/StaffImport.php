<?php
namespace Modules\HRM\Import;

use Date;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;  
use Modules\HRM\Models\Staff;
use App\Models\User; 
use Modules\HRM\Models\StaffAddress;  
use Modules\HRM\Models\HRMStaffBankDetails;
use ApiHelper;
use App\Models\Country;


class StaffImport implements ToModel, WithHeadingRow
{

     

    public function model(array $row)
    {

        $countries = Country::where('countries_name' , $row['country'])->first();

    
            $user = User::where('email', $row['email'])->first();
            if ($user === null) {

                $user = User::create([
                    'first_name' => $row['name'],
                    'last_name' => '',
                    'email' => $row['email'],
                    'password' => $row['password'],
                    'created_by' => 1, 
                ]); 
            } 

            $staffDetails = Staff::where('user_id', $user->id)->first();

            if ($staffDetails != null) {
                 
            } else {


                $staff = Staff::create([
                    'employee_id' => 'emp' . ApiHelper::generate_random_token('numeric', 6),
                    'user_id' => $user->id, 
                    'gender' => $row['gender'],
                    'staff_name' => $user->first_name,  
                    'staff_email' => $user->email,  
                    'staff_phone' =>$row['contact_number'],  
                    'date_of_joining' => $row['date_of_joining'],   
                    'marital_status' => $row['marital_status'],  
                    'date_of_birth' => $row['date_of_birth'],  
                    'verification_status' => 0,
                    'salary' => $row['salary'],
                    'created_by' => 1,
                    'updated_by' => 1  
                ]);


                 if ($row['street_address'] || $row['city'] || $row['state'] || $row['postcode'] || $row['country']) {
                    $staffAddress = StaffAddress::create([
                        'staff_id' => $staff->staff_id,
                        'address_type' => 1,
                        'street_address' => $row['street_address'],
                        'city' => $row['city'],
                        'state' => $row['state'],
                        'postcode' => $row['postcode'],
                        'countries_id' => $countries->countries_id ?? 0, 
                    ]); 
                 
                }


                if ($row['account_name'] || $row['account_number'] || $row['bank_name'] || $row['bank_indetifier_coder'] || $row['bank_branch']) {
                    HRMStaffBankDetails::create([
                            'staff_id' => $staff->staff_id,
                            'account_name' => $row['account_name'],
                            'account_number' =>  $row['account_number'], 
                            'bank_name' =>  $row['bank_name'], 
                            'bank_indetifier_coder' =>  $row['bank_indetifier_coder'], 
                            'bank_branch' =>  $row['bank_branch'],  
                        ]); 
                }


               
 
            }

    }
         
}
